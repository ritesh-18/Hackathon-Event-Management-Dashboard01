const express=require("express");
const {creatEvent,getEvents,updateEvent,deleteEvent} = require("../Controllers/eventController");
const router =express.Router();

router.post("/" , creatEvent);
router.get("/", getEvents);
router.get("/:id",updateEvent);
router.put("/:id",deleteEvent);
module.exports=router;