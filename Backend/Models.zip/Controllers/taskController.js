const Task = require('../Models/Task');


//here i am creating all the routes for the task
exports.getTasks=async(req, res)=>{
    try {
        const task=await Task.findById(req.params.id)
        if(!task){
            return res.status(404).json({
                message:"Task not found"
            })
        }
        res.status(200).json({
            task
        })
        
    } catch (error) {
        res.status(500).json({
            error:error.message,
            message:"Error in fetching task"
        })
    }
}

//creating a task for attendee
exports.createTask=async(req, res)=>{
    try {
        const data =req.body;
        const task=await Task.create(data);
        res.status(201).json(task);
        
    } catch (error) {
        res.status(500).json({
            error:error.message,
            message:"Error in creating task"
        })
    }
}
//updating the task Status
exports.updateTaskStatus=async(req, res)=>{
    try {
        const id=req.params.id;
    const task=await Task.findById(id);
    if(!task){
        return res.status(404).json({
            message:"Task not found"
        })
    }
    const data =req.body;
    const updatedTask=await Task.findByIdAndUpdate({_id:id} , data, {new:true});
    res.status(200).json(updatedTask);
    
        
    } catch (error) {
        res.status(500).json({
            error:error.message,
            message:"Error in updating task status"
        })
    }
}